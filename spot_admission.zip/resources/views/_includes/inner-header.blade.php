<!-- header bottom area start -->
	<div class="header-bottom">
		<div class="container">
			<div class="header-bottom-inner">
				<div class="row align-items-center">
					<div class="col-lg-3 col-sm-9">
						<div class="logo">
							<a href="{{ route('home') }}"><img src="{{ url('front-assets/images/icon/logo.png') }}" alt="logo"></a>
						</div>
					</div>
					<div class="col-xl-8 col-lg-7 d-none d-lg-block">
						<div class="main-menu">
							<nav>
								<ul id="m_menu_active">
									<li><a href="{{ route('home') }}">Home</a>
									</li>
									<li><a href="about.php">About</a></li>
									<li><a href="javascript:void(0);">Colleges</a>
										<ul class="submenu">
											<li><a href="{{ route('colleges') }}">colleges</a></li>
											<li><a href="college-details.php">college details</a></li>
										</ul>
									</li>
									<li><a href="javascript:void(0);">faculty</a>
										<ul class="submenu">
											<li><a href="faculties.php">faculties</a></li>
											<li><a href="faculty-details.php">faculty details</a></li>
										</ul>
									</li>
									<li><a href="javascript:void(0);">blog</a>
										<ul class="submenu">
											<li><a href="blog.php">blog</a></li>
											<li><a href="blog-details.php">blog details</a></li>
										</ul>
									</li>
									<li><a href="contact.php">Contact</a></li>
									@if(!Auth::user())
									<li><a href="{{ route('login') }}">Login</a></li>
									<li><a href="{{ route('register') }}">Sign Up</a></li>
									@endif
								</ul>
							</nav>
						</div>
					</div>
					<!--<div class="col-xl-1 col-lg-2 col-sm-3">
						<div class="hb-right">
							<ul> 
								<li class="search_btn"><i class="fa fa-search"></i></li>
							</ul>
						</div>
					</div>-->
					<div class="col-12 d-block d-lg-none">
						<div id="mobile_menu"></div>
					</div>
				</div>
			</div>
		</div>
	</div>
<!-- header bottom area end -->