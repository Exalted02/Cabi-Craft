<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
<div>
<div style="margin-bottom: 15px;">{!!$body!!}</div>
</div>
</body>
</html>