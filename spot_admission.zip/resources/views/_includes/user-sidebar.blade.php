
<div class="col-md-3">
		<!-- Sidebar Widgets -->
	<div class="blog-sidebar mt_0">
		<!-- Archives --> 
		<div class="widget">
			<div class="widget-heading profile_img_box">
				{{--<img alt="Profile picture" src="" class="img-responsive profile_sidebar_img radius_5">--}}
				<h3 class="text-center"><a href="javascript:void(0);">{{$userDetails->name ? $userDetails->name  : 'NA'}}</a></h3>
			</div>
		<div class="astrodivider"><div class="astrodividermask"></div></div>
		<ul class="profile_user_li">
			<li><a href="{{ route('profile') }}" class="{{ (request()->routeIs('profile')) ? 'active' : '' }} "><i class="fa fa-user" aria-hidden="true"></i> Profile</a></li>
			<li><a href="" class=""><i class="fa fa-file-text-o" aria-hidden="true"></i> Application</a></li>
			<li><a href="{{ route('logout') }}" class=""><i class="fa fa-sign-out" aria-hidden="true"></i>Logout</a></li>
		</ul>
		</div>
	</div>
</div>
