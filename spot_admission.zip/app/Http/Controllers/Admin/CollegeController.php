<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use App\Models\College;
use App\Models\Course;
use App\Models\College_images;
use App\Models\College_course;
use App\Models\College_faculties;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use File;

class CollegeController extends Controller
{
    public function mou_colleges()
    {
		$data = College::query()->where('status', '!=', 2)->where('college_type', 1)->get();
		$result['data']=$data;
        return view('admin.college.mou',$result);
    }
    public function manage_mou_college($id='')
    {
		$result = [];
		if($id>0){				
			$arr = College::query()->where('id', $id)->first();
			if($arr){
				$result['name']=$arr->name;
				$result['address']=$arr->address;
				$result['logo_image']=$arr->logo_image;
				$result['college_image']=$arr->college_image;
				$result['video_link']=$arr->video_link;
				$result['description']=$arr->description;
				$result['placement']=$arr->placement;
				$result['address']=$arr->address;
				$result['id']=$arr->id;
			}else{
				$result['name']			='';
				$result['address']		='';
				$result['logo_image']	='';
				$result['college_image']='';
				$result['video_link']	='';
				$result['description']	='';
				$result['placement']	='';
				$result['address']		='';
				$result['id']			= $id;
			}
        }else{
			$result['name']='';
			$result['address']		='';
			$result['logo_image']	='';
			$result['college_image']='';
			$result['video_link']	='';
			$result['description']	='';
			$result['placement']	='';
			$result['address']		='';
			$result['id']=0;
        }
        return view('admin.college.manage_mou_college',$result);
    }
    public function manage_mou_college_process(Request $request)
    {
		if($request->post('id')>0){
			$request->validate([
				'name'=>'required',
				'address'=>'required',
				'logo_image.0' => 'image|mimes:jpeg,png,jpg,gif,svg',
				'college_image.0' => 'image|mimes:jpeg,png,jpg,gif,svg',
				'video_link'=>'required|url',
				'description'=>'required',
				'placement'=>'required',
			],[],[
				'logo_image.0' => 'logo',
				'college_image.0' => 'college image',
			]);
		}else{
			$request->validate([
				'name'=>'required',
				'address'=>'required',
				'logo_image.0' => 'required|image|mimes:jpeg,png,jpg,gif,svg',
				'college_image.0' => 'required|image|mimes:jpeg,png,jpg,gif,svg',
				'video_link'=>'required|url',
				'description'=>'required',
				'placement'=>'required',
			],[],[
				'logo_image.0' => 'logo',
				'college_image.0' => 'college image',
			]);
		}
        if($request->post('id')>0){
			$model=College::find($request->post('id'));
			$model->name=$request->post('name');
			$model->address=$request->post('address');
			// $model->logo_image=$imageName;
			$model->video_link=$request->post('video_link');
			$model->description=$request->post('description');
			$model->placement=$request->post('placement');
			$model->updated_at=date('Y-m-d H:i:s');
			$model->save();
            $msg="MoU college has been updated successfully.";
        }else{
            $model=new College();
			$model->status=1;
			$model->name=$request->post('name');
			$model->address=$request->post('address');
			// $model->logo_image=$imageName;
			$model->video_link=$request->post('video_link');
			$model->description=$request->post('description');
			$model->placement=$request->post('placement');
			$model->college_type=1;
			$model->updated_at=null;
			$model->save();
            $msg="MoU college has been added successfully.";
        }
		if($request->hasFile('logo_image')) {
			$college_id = $model->id;
			$path = 'images/colleges/'.$college_id.'/logo/';
			$thumb_path = 'images/colleges/'.$college_id.'/logo/thumb/';
			$dest_path  		= public_path($path);
			$dest_thumb_path  	= public_path($thumb_path);
			$width 				= '360';
			$height  			= '270';
			foreach ($request->logo_image as $k=>$file) {
				$imageName = uploadResizeImage('', $dest_path, $dest_thumb_path, $width, $height, $file);
			}
			if($request->post('id') > 0){
				$old_image = 'images/colleges/'.$college_id.'/logo/'.$request->post('hid_image')[0];
				$old_image_thumb = 'images/colleges/'.$college_id.'/logo/thumb/'.$request->post('hid_image')[0];
				unlink_files([$old_image,$old_image_thumb]);
			}
			DB::table('colleges')
				->where('id', $model->id)
				->update(['logo_image'=>$imageName]);
		}
		if($request->hasFile('college_image')) {
			$college_id = $model->id;
			$path = 'images/colleges/'.$college_id.'/';
			$thumb_path = 'images/colleges/'.$college_id.'/thumb/';
			$dest_path  		= public_path($path);
			$dest_thumb_path  	= public_path($thumb_path);
			$width 				= '360';
			$height  			= '270';
			foreach ($request->college_image as $k=>$file) {
				$collegeImageName = uploadResizeImage('', $dest_path, $dest_thumb_path, $width, $height, $file);
			}
			if($request->post('id') > 0){
				$old_image = 'images/colleges/'.$college_id.'/'.$request->post('hid_college_image')[0];
				$old_image_thumb = 'images/colleges/'.$college_id.'/thumb/'.$request->post('hid_college_image')[0];
				unlink_files([$old_image,$old_image_thumb]);
			}
			DB::table('colleges')
				->where('id', $model->id)
				->update(['college_image'=>$collegeImageName]);
		}
        $request->session()->flash('message',$msg);
        return redirect('admin/mou-colleges');        
    }
    public function non_mou_colleges()
    {
		$data = College::query()->where('status', '!=', 2)->where('college_type', 2)->get();
		$result['data']=$data;
        return view('admin.college.non-mou',$result);
    }
    public function manage_non_mou_college($id='')
    {
		$result = [];
		if($id>0){				
			$arr = College::query()->where('id', $id)->first();
			if($arr){
				$result['name']=$arr->name;
				$result['address']=$arr->address;
				$result['logo_image']=$arr->logo_image;
				$result['college_image']=$arr->college_image;
				$result['description']=$arr->description;
				$result['placement']=$arr->placement;
				$result['address']=$arr->address;
				$result['id']=$arr->id;
			}else{
				$result['name']			='';
				$result['address']		='';
				$result['logo_image']	='';
				$result['college_image']='';
				$result['description']	='';
				$result['placement']	='';
				$result['address']		='';
				$result['id']			= $id;
			}
        }else{
			$result['name']='';
			$result['address']		='';
			$result['logo_image']	='';
			$result['college_image']='';
			$result['description']	='';
			$result['placement']	='';
			$result['address']		='';
			$result['id']=0;
        }
        return view('admin.college.manage_non_mou_college',$result);
    }
    public function manage_non_mou_college_process(Request $request)
    {
		if($request->post('id')>0){
			$request->validate([
				'name'=>'required',
				'address'=>'required',
				'logo_image.0' => 'image|mimes:jpeg,png,jpg,gif,svg',
				'college_image.0' => 'image|mimes:jpeg,png,jpg,gif,svg',
				'description'=>'required',
				'placement'=>'required',
			],[],[
				'logo_image.0' => 'logo',
				'college_image.0' => 'college image',
			]);
		}else{
			$request->validate([
				'name'=>'required',
				'address'=>'required',
				'logo_image.0' => 'required|image|mimes:jpeg,png,jpg,gif,svg',
				'college_image.0' => 'required|image|mimes:jpeg,png,jpg,gif,svg',
				'description'=>'required',
				'placement'=>'required',
			],[],[
				'logo_image.0' => 'logo',
				'college_image.0' => 'college image',
			]);
		}
        if($request->post('id')>0){
			$model=College::find($request->post('id'));
			$model->name=$request->post('name');
			$model->address=$request->post('address');
			// $model->logo_image=$imageName;
			$model->video_link='';
			$model->description=$request->post('description');
			$model->placement=$request->post('placement');
			$model->updated_at=date('Y-m-d H:i:s');
			$model->save();
            $msg="MoU college has been updated successfully.";
        }else{
            $model=new College();
			$model->status=1;
			$model->name=$request->post('name');
			$model->address=$request->post('address');
			// $model->logo_image=$imageName;
			$model->video_link='';
			$model->description=$request->post('description');
			$model->placement=$request->post('placement');
			$model->college_type=2;
			$model->updated_at=null;
			$model->save();
            $msg="MoU college has been added successfully.";
        }
		if($request->hasFile('logo_image')) {
			$college_id = $model->id;
			$path = 'images/colleges/'.$college_id.'/logo/';
			$thumb_path = 'images/colleges/'.$college_id.'/logo/thumb/';
			$dest_path  		= public_path($path);
			$dest_thumb_path  	= public_path($thumb_path);
			$width 				= '360';
			$height  			= '270';
			foreach ($request->logo_image as $k=>$file) {
				$imageName = uploadResizeImage('', $dest_path, $dest_thumb_path, $width, $height, $file);
			}
			if($request->post('id') > 0){
				$old_image = 'images/colleges/'.$college_id.'/logo/'.$request->post('hid_image')[0];
				$old_image_thumb = 'images/colleges/'.$college_id.'/logo/thumb/'.$request->post('hid_image')[0];
				unlink_files([$old_image,$old_image_thumb]);
			}
			DB::table('colleges')
				->where('id', $model->id)
				->update(['logo_image'=>$imageName]);
		}
		if($request->hasFile('college_image')) {
			$college_id = $model->id;
			$path = 'images/colleges/'.$college_id.'/';
			$thumb_path = 'images/colleges/'.$college_id.'/thumb/';
			$dest_path  		= public_path($path);
			$dest_thumb_path  	= public_path($thumb_path);
			$width 				= '360';
			$height  			= '270';
			foreach ($request->college_image as $k=>$file) {
				$collegeImageName = uploadResizeImage('', $dest_path, $dest_thumb_path, $width, $height, $file);
			}
			if($request->post('id') > 0){
				$old_image = 'images/colleges/'.$college_id.'/'.$request->post('hid_college_image')[0];
				$old_image_thumb = 'images/colleges/'.$college_id.'/thumb/'.$request->post('hid_college_image')[0];
				unlink_files([$old_image,$old_image_thumb]);
			}
			DB::table('colleges')
				->where('id', $model->id)
				->update(['college_image'=>$collegeImageName]);
		}
        $request->session()->flash('message',$msg);
        return redirect('admin/non-mou-colleges');        
    }
	public function college_course_details(Request $request){
		$result = [];
		$html = '';
		$get_course = College_course::query()->where('id', $request->id)->first();
		$college_course = College_course::query()->where('college_id', $request->college_id)->where('course_id', '!=', $get_course->course_id);
		$course_list = Course::query()->where('status', 1)->whereNotIn('id', $college_course->pluck('course_id'))->get();
		$html .= '<option value="">Select Course</option>';
		foreach($course_list as $course_list_val){
			$selected = '';
			if($course_list_val->id == $get_course->course_id){
				$selected = 'selected';
			}
			$html .= '<option value="'.$course_list_val->id.'" '.$selected.'>'.$course_list_val->name.'</option>';
		}
		$result['course'] = $html;
		$result['fees'] = $get_course->fees;
		$result['hid_course_id'] = $request->id;
		echo json_encode($result);
	}
	public function manage_college_courses($id=''){
		//College_images
		$result = [];
		$college_course = College_course::query()->with(['course_details'])->where('college_id', $id);
		$result['data'] = $college_course->get();
		$result['college_id'] = $id;
		$result['courses'] = Course::query()->where('status', 1)->whereNotIn('id', $college_course->pluck('course_id'))->get();
		return view('admin.college.college_courses',$result);
	}
	public function manage_college_course_process(Request $request){
		$request->validate([
			'course'=>'required',
			'fees'=>'required',
		]);
		$college_id = $request->post('college_id');
		if($request->post('hid_course_id')>0){
			$model=College_course::find($request->post('hid_course_id'));
			$model->college_id=$college_id;
			$model->course_id=$request->post('course');
			$model->fees=$request->post('fees');
			$model->updated_at=date('Y-m-d H:i:s');
			$model->save();
            $msg="College course has been updated successfully.";
		}else{
			$model=new College_course();
			$model->college_id=$college_id;
			$model->course_id=$request->post('course');
			$model->fees=$request->post('fees');
			$model->updated_at=null;
			$model->save();
            $msg="College course has been added successfully.";
		}
		$request->session()->flash('message',$msg);
        return redirect('admin/college/college-course/'.$college_id);
	}
	public function course_delete(Request $request){
		$deleted = College_course::where('id',$request->id)->delete();
        if($deleted){
			$request->session()->flash('message','College course has been deleted successfully.');
			return response()->json(['success'=>'College course has been deleted successfully.']);
		}else{
			return response()->json(['success'=>'College course not deleted.']);
		}
    }
	public function multi_course_delete(Request $request){
		$ids = explode(',',$request->id);
		$deleted = College_course::whereIn('id',$ids)->delete();
        if($deleted){
			$request->session()->flash('message','College course has been deleted successfully.');
			return response()->json(['success'=>'College course has been deleted successfully.']);
		}else{
			return response()->json(['success'=>'College course not deleted.']);
		}
    }
	public function college_faculty_details(Request $request){
		$result = [];
		$html = '';
		$get_data = College_faculties::query()->where('id', $request->id)->first();
		$result['faculty_name'] = $get_data->faculty_name;
		$result['faculty_image'] = $get_data->faculty_image;
		$result['hid_faculty_id'] = $request->id;
		echo json_encode($result);
	}
	public function manage_college_faculty($id=''){
		//College_faculties
		$result = [];
		$result['data'] = College_faculties::query()->where('college_id', $id)->get();
		$result['college_id'] = $id;
		return view('admin.college.college_faculty',$result);
	}
	public function manage_college_faculty_process(Request $request){
		if($request->post('hid_faculty_id')>0){
			$request->validate([
				'faculty_name' => 'required',
				'image.0' => 'image|mimes:jpeg,png,jpg,gif,svg',
			],[],[
				'image.0' => 'image',
			]);
		}else{
			$request->validate([
				'faculty_name' => 'required',
				'image.0' => 'required|image|mimes:jpeg,png,jpg,gif,svg',
			],[],[
				'image.0' => 'image',
			]);
		}
		$college_id = $request->post('college_id');
		if($request->hasFile('image')) {
			$path = 'images/colleges/'.$college_id.'/faculty/';
			$thumb_path = 'images/colleges/'.$college_id.'/faculty/thumb/';
			$dest_path  		= public_path($path);
			$dest_thumb_path  	= public_path($thumb_path);
			$width 				= '360';
			$height  			= '270';
			foreach ($request->image as $k=>$file) {
				$imageName = uploadResizeImage('', $dest_path, $dest_thumb_path, $width, $height, $file);
			}
			if($request->post('hid_faculty_id') > 0){
				$old_image = 'images/colleges/'.$college_id.'/faculty/'.$request->post('hid_image');
				$old_image_thumb = 'images/colleges/'.$college_id.'/faculty/thumb/'.$request->post('hid_image');
				unlink_files([$old_image,$old_image_thumb]);
			}				
		}else{
			$imageName = $request->post('hid_image');
		}
		if($request->post('hid_faculty_id')>0){
			$model=College_faculties::find($request->post('hid_faculty_id'));
			$model->college_id=$college_id;
			$model->faculty_image=$imageName;
			$model->faculty_name=$request->post('faculty_name');
			$model->updated_at=date('Y-m-d H:i:s');
			$model->save();
            $msg="Faculty image has been updated successfully.";
		}else{
			$model=new College_faculties();
			$model->college_id=$college_id;
			$model->faculty_image=$imageName;
			$model->faculty_name=$request->post('faculty_name');
			$model->updated_at=null;
			$model->save();
            $msg="Faculty image has been added successfully.";
		}
		$request->session()->flash('message',$msg);
        return redirect('admin/college/college-faculty/'.$college_id);
	}
	public function faculty_delete(Request $request){
		//For delete the image from folder path start
		$select_image = College_faculties::where('id',$request->id)->first();
		$old_image = 'images/colleges/'.$select_image->college_id.'/faculty/'.$select_image->image;
		$old_image_thumb = 'images/colleges/'.$select_image->college_id.'/faculty/thumb/'.$select_image->image;
		unlink_files([$old_image,$old_image_thumb]);
		//For delete the image from folder path end
		$deleted = College_faculties::where('id',$request->id)->delete();
        if($deleted){
			$request->session()->flash('message','Faculty image has been deleted successfully.');
			return response()->json(['success'=>'Faculty image has been deleted successfully.']);
		}else{
			return response()->json(['success'=>'Faculty not deleted.']);
		}
    }
	public function multi_faculty_delete(Request $request){
		$ids = explode(',',$request->id);
		foreach($ids as $id_val){
			//For delete the image from folder path start
			$select_image = College_faculties::where('id',$id_val)->first();
			$old_image = 'images/colleges/'.$select_image->college_id.'/faculty/'.$select_image->image;
			$old_image_thumb = 'images/colleges/'.$select_image->college_id.'/faculty/thumb/'.$select_image->image;
			unlink_files([$old_image,$old_image_thumb]);
			//For delete the image from folder path end
		}
		$deleted = College_faculties::whereIn('id',$ids)->delete();
        if($deleted){
			$request->session()->flash('message','Faculty image has been deleted successfully.');
			return response()->json(['success'=>'Faculty image has been deleted successfully.']);
		}else{
			return response()->json(['success'=>'Faculty image not deleted.']);
		}
    }
	public function manage_college_images($id=''){
		//College_images
		$result = [];
		$result['data'] = College_images::query()->where('college_id', $id)->get();
		$result['college_id'] = $id;
		return view('admin.college.college_images',$result);
	}
	public function manage_college_images_process(Request $request){
		if($request->post('hid_image_id')>0){
			$request->validate([
				'image.0' => 'image|mimes:jpeg,png,jpg,gif,svg',
			],[],[
				'image.0' => 'image',
			]);
		}else{
			$request->validate([
				'image.0' => 'required|image|mimes:jpeg,png,jpg,gif,svg',
			],[],[
				'image.0' => 'image',
			]);
		}
		$college_id = $request->post('college_id');
		if($request->hasFile('image')) {
			$path = 'images/colleges/'.$college_id.'/images/';
			$thumb_path = 'images/colleges/'.$college_id.'/images/thumb/';
			$dest_path  		= public_path($path);
			$dest_thumb_path  	= public_path($thumb_path);
			$width 				= '360';
			$height  			= '270';
			foreach ($request->image as $k=>$file) {
				$imageName = uploadResizeImage('', $dest_path, $dest_thumb_path, $width, $height, $file);
			}
			if($request->post('hid_image_id') > 0){
				$old_image = 'images/colleges/'.$college_id.'/images/'.$request->post('hid_image');
				$old_image_thumb = 'images/colleges/'.$college_id.'/images/thumb/'.$request->post('hid_image');
				unlink_files([$old_image,$old_image_thumb]);
			}				
		}else{
			$imageName = $request->post('hid_image');
		}
		if($request->post('hid_image_id')>0){
			$model=College_images::find($request->post('hid_image_id'));
			$model->college_id=$college_id;
			$model->image=$imageName;
			$model->updated_at=date('Y-m-d H:i:s');
			$model->save();
            $msg="College image has been updated successfully.";
		}else{
			$model=new College_images();
			$model->college_id=$college_id;
			$model->image=$imageName;
			$model->updated_at=null;
			$model->save();
            $msg="College image has been added successfully.";
		}
		$request->session()->flash('message',$msg);
        return redirect('admin/college/college-images/'.$college_id);
	}
	public function image_delete(Request $request){
		//For delete the image from folder path start
		$select_image = College_images::where('id',$request->id)->first();
		$old_image = 'images/colleges/'.$select_image->college_id.'/images/'.$select_image->image;
		$old_image_thumb = 'images/colleges/'.$select_image->college_id.'/images/thumb/'.$select_image->image;
		unlink_files([$old_image,$old_image_thumb]);
		//For delete the image from folder path end
		$deleted = College_images::where('id',$request->id)->delete();
        if($deleted){
			$request->session()->flash('message','College image has been deleted successfully.');
			return response()->json(['success'=>'College image has been deleted successfully.']);
		}else{
			return response()->json(['success'=>'College not deleted.']);
		}
    }
	public function multi_image_delete(Request $request){
		$ids = explode(',',$request->id);
		foreach($ids as $id_val){
			//For delete the image from folder path start
			$select_image = College_images::where('id',$id_val)->first();
			$old_image = 'images/colleges/'.$select_image->college_id.'/images/'.$select_image->image;
			$old_image_thumb = 'images/colleges/'.$select_image->college_id.'/images/thumb/'.$select_image->image;
			unlink_files([$old_image,$old_image_thumb]);
			//For delete the image from folder path end
		}
		$deleted = College_images::whereIn('id',$ids)->delete();
        if($deleted){
			$request->session()->flash('message','College image has been deleted successfully.');
			return response()->json(['success'=>'College image has been deleted successfully.']);
		}else{
			return response()->json(['success'=>'College image not deleted.']);
		}
    }
	public function delete(Request $request){
		$deleted = College::where('id',$request->id)
			->update(['status'=>2]);
        if($deleted){
			$request->session()->flash('message','College has been deleted successfully.');
			return response()->json(['success'=>'College has been deleted successfully.']);
		}else{
			return response()->json(['success'=>'College not deleted.']);
		}
    }
	public function multi_delete(Request $request){
		$ids = explode(',',$request->id);
		$deleted = College::whereIn('id',$ids)
			->update(['status'=>2]);
        if($deleted){
			$request->session()->flash('message','College has been deleted successfully.');
			return response()->json(['success'=>'College has been deleted successfully.']);
		}else{
			return response()->json(['success'=>'College not deleted.']);
		}
    }
	public function status(Request $request){
		$updated = College::where('id',$request->id)
			->update(['status'=>$request->val]);
        
        if($updated){
			$request->session()->flash('message','College status has been updated successfully.');
			return response()->json(['success'=>'College status has been updated successfully.']);
		}else{
			return response()->json(['success'=>'College not updated.']);
		}
    }
	public function multi_change_status(Request $request){
		$cat_ids = explode(',',$request->id);
		$updated = College::whereIn('id',$cat_ids)
				->update(['status'=>$request->status]);
        if($updated){
			$request->session()->flash('message','College status has been updated successfully.');
			return response()->json(['success'=>'College status has been updated successfully.']);
		}else{
			return response()->json(['success'=>'College not updated.']);
		}
    }
}
