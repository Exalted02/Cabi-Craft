@extends('layouts.app')
@section('content')

<div class="crumbs-area">
	<div class="container">
		<div class="crumb-content">
			<h4 class="crumb-title"><span>Profile </span></h4>
		</div>
	</div>
</div>
<!-- crumbs area end -->
<div class="contact-form-area pb--120">
	<div class="container">
		<div class="row">
			@include('_includes/user-sidebar')
		<div class="col-md-9">
		<div class="row">
			<div class="col-md-12">
				<div class="cnt-title">
					<h4>Update your profile <span>Here</span></h4>
					{{--<p>Quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut </p>--}}
				</div>
			</div>
		</div>
		<div class="contact-form">
			<form action="{{ route('profile_submit') }}" method="post" enctype="multipart/form-data">
			@csrf
				<div class="row">
					<div class="col-md-9 offset-md-1">
						<input type="text" id="name" name="name"  placeholder="Your Name" class="" value="{{$user->name}}">
						@error('name')
						<span class="text-danger">
							{{ $message }}
						</span>
						@enderror
					</div>
					<div class="col-md-4 offset-md-1">
						<input type="text" id="contact_number" name="contact_number"  placeholder="Your Contact number" class="" value="{{  $user->contact_number }}">
						@error('contact_number')
						<span class="text-danger">
							{{ $message }}
						</span>
						@enderror
					</div>
					<div class="col-md-4 offset-md-1">
						<input type="email" id="email" name="email" placeholder="Your Email" class="" value="{{ $user->email }}" disabled>
						@error('email')
						<span class="text-danger">
							{{ $message }}
						</span>
						@enderror
					</div>
					<div class="col-md-4 offset-md-1">
						<input id="password" class="" type="password" name="password" placeholder="New password"/>
						@error('password')
						<span class="text-danger">
							{{ $message }}
						</span>
						@enderror
					</div>
					<div class="col-md-4 offset-md-1">
						<input id="password_confirmation" class="" type="password" name="password_confirmation" placeholder="Confirm new password"/>
						@error('password_confirmation')
						<span class="text-danger">
							{{ $message }}
						</span>
						@enderror
					</div>
					<div class="col-md-8 offset-md-2 text-center">
						<button type="submit">SUBMIT</button>
					</div>
				</div>
			</form>
		</div>
	
		</div>
		</div>
	</div>
</div>
	
@endsection
@section('scripts')
<script>

</script>
@endsection
