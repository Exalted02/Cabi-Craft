@extends('layouts.app')
@section('content')
 <!-- hero area start -->
    <div class="hero-area has-color">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2 col-md-10 offset-md-1">
                    <div class="hero-content">
                        <h3>Admission'24</h3>
                        <h1 class="mb-5"><span class="primary-color">Build your Successful</span><b class="line-break"></b>Future with Spot Admission</h1>
                        <p class="text-white-50">Find Your Preferred Colleges & Improve Your Skills</p>
                        <form action="#">
                            <div class="form-input mt-5">
                                <input type="text" name="search" required placeholder="Enter your keyword...">
                                <button class="btn btn-primary btn-round" type="submit">Seacrh</button>
                                <i class="fa fa-search"></i>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- hero area end -->


    <!-- college area start -->
    <div class="course-area  ptb--30">
        <div class="container">
            <div class="row">
                <div class="col-md-10 offset-md-1">
                    <div class="section-title-style2 black-title title-tb text-center">
                        <span>build your career</span>
                        <h2 class="primary-color">Top Colleges</h2>
                    </div>
                </div>
            </div>
  
            <div class="commn-carousel owl-carousel card-deck college-list"> 
			@foreach($colleges as $college_val)
                <div class="card mb-5">
                    <div class="course-thumb">
						<div class="image-background" style="background-image: url('{{ isset($college_val->college_image) && $college_val->college_image!='' ? asset('images/colleges').'/'.$college_val->id.'/'.$college_val->college_image : asset('/images/noimage.png') }}');"></div>
                        <img src="{{ isset($college_val->college_image) && $college_val->college_image!='' ? asset('images/colleges').'/'.$college_val->id.'/'.$college_val->college_image : asset('/images/noimage.png') }}" alt="image">
                    </div>
                    <div class="card-body  p-10"> 
                        <div class="course-meta-title mb-2">
                            <div class="course-meta-text">
                                <h4><a href="{{url('college-details')}}/{{$college_val->id}}">{{$college_val->name}}</a></h4>
                            </div>
                        </div>
                        <p class="description">College Description -- {{$college_val->description}}</p> 
						<p class="small-text">{{$college_val->address}}</p>
                        <ul class="course-meta-details list-inline w-100">
                            <li> 
                             <p>1st Year Fees</p>
                             <span>₹230,550</span>
                            </li>
                            <li><a class="btn btn-primary btn-custom" href="">Courses & Fees</a>
                            </li>      
                        </ul>  
                  </div><!-- card-body -->
                </div><!-- card -->
			@endforeach
            </div> 
			<div class="ptb--20">
				<div class="container text-center">
					<div class="row">
						<div class="col-lg-12 col-md-12">
							<a class="btn btn-primary btn-lg" href="{{ route('colleges') }}">All Colleges</a>
						</div> 
					</div>
				</div>
			</div>
			
        </div>
    </div>
	
    <!-- colleges area end -->
	

    <!-- take toure area start -->
    <div class="take-toure-area ptb--30">
        <div class="container">
            <div class="row">
                <div class="col-md-10 offset-md-1">
                    <div class="section-title-style2 white-title text-center">
                        <span>Take A Look</span>
                        <h2>Video Tour on Spot Admission </h2>
                    </div>
                </div>
            </div>
            <div class="video-area">
                <a class="expand-video" href="https://www.youtube.com/watch?v=cdfMgotGKIM"><i class="fa fa-play"></i></a>
            </div>
        </div>
    </div>
    <!-- take toure area end -->

    <!-- course area start -->
    <div class="teacher-area pb--30">
        <div class="container">
            <div class="row">
                <div class="col-md-10 offset-md-1">
                    <div class="section-title-style2 black-title title-tb text-center">
                        <span>Learn from the best</span>
                        <h2 class="primary-color">Our faculties</h2>
                    </div>
                </div>
            </div>
            <div class="commn-carousel owl-carousel card-deck">   
              <div class="card mb-5"> 
                <img src="{{ url('front-assets/images/teacher/teacher-member1.jpg') }}" alt="image"> 
                <div class="card-body teacher-content p-25">  
                  <h4 class="card-title mb-4"><a href="teacher-details.php">Patrick Garner Dony</a></h4>
                  <span class="primary-color d-block mb-4">Economist</span>
                  <p class="card-text">We’re a philosophical bunch here at School site and we have thought long and hard about.</p> 
                  <ul class="list-inline ">
                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                    <li><a href="#"><i class="fa fa-deviantart"></i></a></li>
                    <li><a href="#"><i class="fa fa-github"></i></a></li>
                  </ul>
                </div>
              </div><!-- card -->    

              <div class="card mb-5"> 
                <img src="{{ url('front-assets/images/teacher/teacher-member2.jpg') }}" alt="image"> 
                <div class="card-body teacher-content p-25">  
                  <h4 class="card-title mb-4"><a href="teacher-details.php">Cameron Brown</a></h4>
                  <span class="primary-color  d-block mb-4">Financier</span>
                  <p class="card-text">We’re a philosophical bunch here at School site and we have thought long and hard about.</p> 
                  <ul class="list-inline ">
                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                    <li><a href="#"><i class="fa fa-deviantart"></i></a></li>
                    <li><a href="#"><i class="fa fa-github"></i></a></li>
                  </ul>
                </div>
              </div><!-- card -->    

              <div class="card mb-5"> 
                <img src="{{ url('front-assets/images/teacher/teacher-member3.jpg') }}" alt="image"> 
                <div class="card-body teacher-content p-25">  
                  <h4 class="card-title mb-4"><a href="teacher-details.php">Joseph Mack Monika</a></h4>
                  <span class="primary-color d-block mb-4">Languages</span>
                  <p class="card-text">We’re a philosophical bunch here at School site and we have thought long and hard about.</p> 
                  <ul class="list-inline ">
                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                    <li><a href="#"><i class="fa fa-deviantart"></i></a></li>
                    <li><a href="#"><i class="fa fa-github"></i></a></li>
                  </ul>
                </div>
              </div><!-- card -->  
              <div class="card mb-5"> 
                <img src="{{ url('front-assets/images/teacher/teacher-member4.jpg') }}" alt="image"> 
                <div class="card-body teacher-content p-25">  
                  <h4 class="card-title mb-4"><a href="teacher-details.php">Patrick Garner Dony</a></h4>
                  <span class="primary-color d-block mb-4">Economist</span>
                  <p class="card-text">We’re a philosophical bunch here at School site and we have thought long and hard about.</p> 
                  <ul class="list-inline ">
                    <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                    <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                    <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                    <li><a href="#"><i class="fa fa-deviantart"></i></a></li>
                    <li><a href="#"><i class="fa fa-github"></i></a></li>
                  </ul>
                </div>
              </div><!-- card -->         
            </div>
        </div>
    </div>
    <!-- course area end -->

    <!-- events area start -->
    <div class="event-area  ptb--30">
        <div class="container">
            <div class="row">
                <div class="col-md-10 offset-md-1">
                    <div class="section-title-style2 black-title text-center">
                        <span>Join with us</span>
                        <h2>Upcoming Events</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="media align-items-center mb-5">
                        <div class="media-head primary-bg">
                            <span><sub>MAR</sub>25</span>
                            <p>2018</p>
                        </div>
                        <div class="media-body">
                            <h4><a href="#">Affiliate Marketing</a></h4>
                            <p><i class="fa fa-clock-o"></i>05:23 AM - 09:23 AM</p>
                        </div>
                    </div> <!-- media -->
                </div><!-- col-md-6 -->
                <div class="col-md-6">
                    <div class="media align-items-center mb-5">
                        <div class="media-head primary-bg">
                            <span><sub>OCT</sub>25</span>
                            <p>2018</p>
                        </div>
                        <div class="media-body">
                            <h4><a href="#">Facebook Marketing</a></h4>
                            <p><i class="fa fa-clock-o"></i>05:23 AM - 09:23 AM</p>
                        </div>
                    </div> <!-- media -->
                </div><!-- col-md-6 --> 
                <div class="col-md-6">
                    <div class="media align-items-center mb-5">
                        <div class="media-head primary-bg">
                            <span><sub>NOV</sub>25</span>
                            <p>2018</p>
                        </div>
                        <div class="media-body">
                            <h4><a href="#">Edustar Autumn</a></h4>
                            <p><i class="fa fa-clock-o"></i>05:23 AM - 09:23 AM</p>
                        </div>
                    </div> <!-- media -->
                </div><!-- col-md-6 -->  
                <div class="col-md-6">
                    <div class="media align-items-center mb-5">
                        <div class="media-head primary-bg">
                            <span><sub>DEC</sub>25</span>
                            <p>2018</p>
                        </div>
                        <div class="media-body">
                            <h4><a href="#">Workshop PHP</a></h4>
                            <p><i class="fa fa-clock-o"></i>05:23 AM - 09:23 AM</p>
                        </div>
                    </div> <!-- media -->
                </div><!-- col-md-6 -->   
            </div><!-- row -->
        </div><!-- container -->
    </div>
    <!-- events area end --> 
    
    <div class="testimonial-area ptb--30"><!-- testimonial area start -->
        <img class="tst-bg" src="{{ url('front-assets/images/bg/tst-bg-shape.png') }}" alt="image">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 offset-lg-3 text-center">
                    <div class="tst-carousel owl-carousel">
                        <div class="testimonial-content pb--40">
                            <div class="section-title sec-style-two">
                                <span class="text-uppercase primary-color mb-0">Happy students</span>
                                <h2>Testimonial</h2>
                            </div>
                            <h3>‘‘ Vous devez profiter de la vie. Toujours aimez, les personnespositives penser. ‘‘</h3>
                            <h4>Kawsar Ahhamed</h4>
                            <span>App Developer</span>
                        </div>  
                        <div class="testimonial-content pb--40">
                            <div class="section-title sec-style-two">
                                <span class="text-uppercase primary-color mb-0">Happy students</span>
                                <h2>Testimonial</h2>
                            </div>
                            <h3>‘‘ Vous devez profiter de la vie. Toujours aimez, les personnespositives penser. ‘‘</h3>
                            <h4>Kawsar Ahhamed</h4>
                            <span>App Developer</span>
                        </div>  
                        <div class="testimonial-content pb--40">
                            <div class="section-title sec-style-two">
                                <span class="text-uppercase primary-color mb-0">Happy students </span>
                                <h2>Testimonial</h2>
                            </div>
                            <h3>‘‘ Vous devez profiter de la vie. Toujours aimez, les personnespositives penser. ‘‘</h3>
                            <h4>Kawsar Ahhamed</h4>
                            <span>App Developer</span>
                        </div> 
                    </div>
                </div><!-- row -->
            </div><!-- row -->
        </div><!-- container -->
    </div><!-- testimonial-area --> 

    <!-- blog area start -->
    <div class="feature-blog  ptb--30">
        <div class="container">
            <div class="row">
                <div class="col-md-10 offset-md-1">
                    <div class="section-title-style2 black-title title-tb text-center">
                        <span>Top stories</span>
                        <h2>Blog & News</h2>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="blog-carousel owl-carousel card-deck">                     
                  <div class="card mb-5"> 
                    <img class="card-img-top" src="{{ url('front-assets/images/blog/blog-thumbnail1.jpg') }}" alt="image">
                    <div class="card-body p-25"> 
                        <ul class="list-inline primary-color mb-3">
                            <li><i class="fa fa-clock-o"></i> AUGUST 6, 2017</li>
                            <li><i class="fa fa-comments"></i> 3 Comments</li>
                        </ul>
                      <h4 class="card-title mb-4"><a href="blog.php">The Death Of architechture</a></h4>
                      <p class="card-text">We’re a philosophical bunch here at School site and we have thought long and hard about.</p> 
                      <a class="btn btn-primary btn-round btn-sm" href="courses.php"> Read More </a>
                    </div>
                  </div><!-- card -->                
                  <div class="card mb-5"> 
                    <img class="card-img-top" src="{{ url('front-assets/images/blog/blog-thumbnail2.jpg') }}" alt="image">
                    <div class="card-body p-25"> 
                        <ul class="list-inline primary-color mb-3">
                            <li><i class="fa fa-clock-o"></i> AUGUST 6, 2017</li>
                            <li><i class="fa fa-comments"></i> 3 Comments</li>
                        </ul>
                      <h4 class="card-title mb-4"><a href="blog.php">Aenean id ullamcorper</a></h4>
                      <p class="card-text">We’re a philosophical bunch here at School site and we have thought long and hard about.</p> 
                      <a class="btn btn-primary btn-round btn-sm" href="courses.php"> Read More </a>
                    </div>
                  </div><!-- card -->
       
                  <div class="card mb-5"> 
                    <img class="card-img-top" src="{{ url('front-assets/images/blog/blog-thumbnail3.jpg') }}" alt="image">
                    <div class="card-body p-25"> 
                        <ul class="list-inline primary-color mb-3">
                            <li><i class="fa fa-clock-o"></i> AUGUST 6, 2017</li>
                            <li><i class="fa fa-comments"></i> 3 Comments</li>
                        </ul>
                      <h4 class="card-title mb-4"><a href="blog.php">The Death Of architechture</a></h4>
                      <p class="card-text">We’re a philosophical bunch here at School site and we have thought long and hard about.</p> 
                      <a class="btn btn-primary btn-round btn-sm" href="courses.php"> Read More </a>
                    </div>
                  </div><!-- card -->         
                  <div class="card mb-5"> 
                    <img class="card-img-top" src="{{ url('front-assets/images/blog/blog-thumbnail1.jpg') }}" alt="image">
                    <div class="card-body p-25"> 
                        <ul class="list-inline primary-color mb-3">
                            <li><i class="fa fa-clock-o"></i> AUGUST 6, 2017</li>
                            <li><i class="fa fa-comments"></i> 3 Comments</li>
                        </ul>
                      <h4 class="card-title mb-4"><a href="blog.php">The Death Of architechture</a></h4>
                      <p class="card-text">We’re a philosophical bunch here at School site and we have thought long and hard about.</p> 
                      <a class="btn btn-primary btn-round btn-sm" href="courses.php"> Read More </a>
                    </div>
                  </div><!-- card -->    
                </div><!-- blog-carousel -->
            </div><!-- blog-carousel -->

        </div>
    </div> <!-- blog area end -->
@endsection
@section('scripts')

@endsection

