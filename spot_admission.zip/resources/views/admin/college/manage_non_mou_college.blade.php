@extends('admin.layouts.app')

@section('content')
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.css" />
<style type="text/css">
	.datepicker {
		font-size: 0.875em;
	}
	.datepicker td, .datepicker th {
		width: 2em;
		height: 2em;
		padding: 5px;
	}
</style>
<main class="content">
	<div class="container-fluid p-0">
        <h1 class="h3 mb-3"><strong>{{$id=='0' ? "Add new" : "Edit"}}</strong> non MoU College</h1>
        <div class="card">
			<form id="cat_form" action="{{route('admin.college.manage_non_mou_college_process')}}" enctype="multipart/form-data" method="post">
			@csrf
			<div class="card-body">
				<div class="row add_cat mb-3">
					<div class="col-lg-2">
						<h5 class="card-title mb-2">College Name<sup>*</sup></h5>
					</div>
					<div class="col-lg-10">
						@if ($id=='0')
						<input type="text" name="name" value="{{old('name')}}" class="form-control" placeholder="College Name">
						
						@else
						<input type="text" name="name" value="{{$name}}" class="form-control" placeholder="College Name">
							
						@endif
						@error('name')
						<span class="text-danger">
							{{$message}}		
						</span>
						@enderror
					</div>
				</div>
				<div class="row add_cat mb-3">
					<div class="col-lg-2">
						<h5 class="card-title mb-2">Address<sup>*</sup></h5>
					</div>
					<div class="col-lg-10">
						@if ($id=='0')
						<input type="text" name="address" value="{{old('address')}}" class="form-control" placeholder="Address">
						
						@else
						<input type="text" name="address" value="{{$address}}" class="form-control" placeholder="Address">
							
						@endif
						@error('address')
						<span class="text-danger">
							{{$message}}		
						</span>
						@enderror
					</div>
				</div>
				
				<div class="row updateCMSrow mb-3">
					<div class="col-lg-2">
						<h5 class="card-title mb-2">Logo</h5>
					</div>
					<div class="col-lg-10">
						<div class="row imageSection">
							<div class="col-lg-4 col-md-4 col-sm-6 col-12 imgRow">
								@if(isset($logo_image) && $logo_image!='')
								<div class="imgField"><img id="imgSrc0" src="{{ asset('images/colleges') }}/{{$id}}/logo/{{$logo_image}}"></div>
								<input type="hidden" name="hid_image[]" value="{{$logo_image}}" />
								@else
								<div class="imgField"><img id="imgSrc0" src="{{ asset('/images/noimage.png') }}" /></div>
								<input type="hidden" name="hid_image[]" />
								@endif
								@error('logo_image.0')
								<span class="text-danger">
									{{$message}}		
								</span>
								@enderror
								<div class="fileUpload btn btn-secondary">
									<span>Select Logo Image</span>
									<input type="file" class="upload" data-id="0" name="logo_image[]" />
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="row updateCMSrow mb-3">
					<div class="col-lg-2">
						<h5 class="card-title mb-2">College Image</h5>
					</div>
					<div class="col-lg-10">
						<div class="row imageSection">
							<div class="col-lg-4 col-md-4 col-sm-6 col-12 imgRow">
								@if(isset($college_image) && $college_image!='')
								<div class="imgField"><img id="imgCollegeSrc0" src="{{ asset('images/colleges') }}/{{$id}}/{{$college_image}}"></div>
								<input type="hidden" name="hid_college_image[]" value="{{$college_image}}" />
								@else
								<div class="imgField"><img id="imgCollegeSrc0" src="{{ asset('/images/noimage.png') }}" /></div>
								<input type="hidden" name="hid_college_image[]" />
								@endif
								@error('college_image.0')
								<span class="text-danger">
									{{$message}}		
								</span>
								@enderror
								<div class="fileUpload btn btn-secondary">
									<span>Select College Image</span>
									<input type="file" class="uploadcollege" data-id="0" name="college_image[]" />
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="row add_cat mb-3">
					<div class="col-lg-2">
						<h5 class="card-title mb-2">Description<sup>*</sup></h5>
					</div>
					<div class="col-lg-10">
						@if ($id=='0')
						<textarea name="description" class="form-control" placeholder="Description">{{old('description')}}</textarea>
						@else
						<textarea name="description" class="form-control" placeholder="Description">{{$description}}</textarea>
							
						@endif
						@error('description')
						<span class="text-danger">
							{{$message}}		
						</span>
						@enderror
					</div>
				</div>
				<div class="row add_cat mb-3">
					<div class="col-lg-2">
						<h5 class="card-title mb-2">Placement<sup>*</sup></h5>
					</div>
					<div class="col-lg-10">
						@if ($id=='0')
						<textarea name="placement" class="form-control" placeholder="Placement">{{old('placement')}}</textarea>	
						
						@else
						<textarea name="placement" class="form-control" placeholder="Placement">{{$placement}}</textarea>	
						@endif
						@error('placement')
						<span class="text-danger">
							{{$message}}		
						</span>
						@enderror
					</div>
				</div>
				<div class="row add_cat_submit mt-3">
					<div class="col-lg-2"></div>
					<div class="col-lg-10">
						<a href="{{ route('admin.colleges.mou') }}"><button type="button" class="btn btn-danger">Cancel</button></a>
						<button type="submit" class="btn btn-success">Submit</button>
					</div>
				</div>
				<input type="hidden" name="id" value="{{$id}}"/>
				</form>
			</div>
		</div>
    </div>
</main>
@endsection

@section('scripts')
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
<script>
	$(".datepicker").datepicker({
		clearBtn: true,
		format: "dd/mm/yyyy",
	});
</script>
<script type="text/javascript">
$(document).ready(function (e) {
	$('.upload').change(function(){
		var id = $(this).data('id');
		let reader = new FileReader();
		reader.onload = (e) => {
			$("#imgSrc"+id).attr('src', e.target.result);
		}
		reader.readAsDataURL(this.files[0]);
	});
	$('.uploadcollege').change(function(){
		var id = $(this).data('id');
		let reader = new FileReader();
		reader.onload = (e) => {
			$("#imgCollegeSrc"+id).attr('src', e.target.result);
		}
		reader.readAsDataURL(this.files[0]);
	});
});
</script>
@endsection