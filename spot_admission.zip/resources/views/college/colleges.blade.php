@extends('layouts.app')
@section('content')
 <!-- crumbs area start -->
    <div class="crumbs-area">
        <div class="container">
            <div class="crumb-content">
                <h4 class="crumb-title"><span>College</span> List</h4>
            </div>
        </div>
    </div>
    <!-- crumbs area end -->
    <div class="course-area  pt--120 pb--70">
        <div class="container">
			@if(count($colleges) > 0)
            <div class="row"> 
				@foreach($colleges as $college_val)
                <div class="col-lg-4 col-md-6 college-list">
                    <div class="card mb-5">
						<div class="course-thumb">
							<div class="image-background" style="background-image: url('{{ isset($college_val->college_image) && $college_val->college_image!='' ? asset('images/colleges').'/'.$college_val->id.'/'.$college_val->college_image : asset('/images/noimage.png') }}');"></div>
							<img src="{{ isset($college_val->college_image) && $college_val->college_image!='' ? asset('images/colleges').'/'.$college_val->id.'/'.$college_val->college_image : asset('/images/noimage.png') }}" alt="image">
						</div>
						<div class="card-body  p-10"> 
							<div class="course-meta-title mb-2">
								<div class="course-meta-text">
									<h4><a href="{{url('college-details')}}/{{$college_val->id}}">{{$college_val->name}}</a></h4>
								</div>
							</div>
							<p class="description">College Description -- {{$college_val->description}}</p> 
							<p class="small-text">{{$college_val->address}}</p>
							<ul class="course-meta-details list-inline w-100">
								<li> 
								 <p>1st Year Fees</p>
								 <span>₹230,550</span>
								</li>
								<li><a class="btn btn-primary btn-custom" href="">Courses & Fees</a>
								</li>      
							</ul>  
					  </div><!-- card-body -->
					</div><!-- card -->
                </div>
				@endforeach				
            </div>
			{{--<div class="ptb--20">
				<div class="container text-center">
					<div class="row">
						<div class="col-lg-12 col-md-12">
							<a class="btn btn-primary btn-lg" href="#">Load More..</a>
						</div> 
					</div>
				</div>
			</div>--}}
			@else
			<div class="row"> 	
				<div class="col-lg-12 text-center">
					No college found!
				</div>
			</div>
			@endif
        </div>
    </div>
@endsection
@section('scripts')

@endsection

