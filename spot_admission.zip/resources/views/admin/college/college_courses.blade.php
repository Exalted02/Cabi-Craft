@extends('admin.layouts.app')

@section('content')
<main class="content">
	<div class="container-fluid p-0">
		<div class="row">
			<div class="col-lg-12">
				<h1 class="h3 mb-3"><span id="form_type">Add</span> Course</h1>
			</div>
		</div>
        <div id="message"></div>
		@if(session('message') )
		<div class="alert alert-success alert-dismissible fade show">
			<strong>{{session('message')}}</strong> 
			<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="btn-close">
			</button>
		</div>
		@endif
		<div class="card">
			<form id="cat_form" action="{{route('admin.college.manage_college_course_process')}}" enctype="multipart/form-data" method="post">
			@csrf
			<div class="card-body">
				<div class="row updateCMSrow mb-3">
					<div class="col-lg-2">
						<h5 class="card-title mb-2">Course<sup>*</sup></h5>
					</div>
					<div class="col-lg-10">
						<div class="row">
							<div class="col-lg-4 col-md-4 col-sm-6 col-12">
								<select class="form-control" name="course" id="course">
									<option value="">Select Course</option>
									@foreach($courses as $course_val)
									<option value="{{$course_val->id}}">{{$course_val->name}}</option>
									@endforeach
								</select>
								@error('course')
								<span class="text-danger">
									{{$message}}		
								</span>
								@enderror
							</div>
						</div>
					</div>
				</div>
				<div class="row updateCMSrow mb-3">
					<div class="col-lg-2">
						<h5 class="card-title mb-2">Fees({{currency()}})<sup>*</sup></h5>
					</div>
					<div class="col-lg-10">
						<div class="row">
							<div class="col-lg-4 col-md-4 col-sm-6 col-12">
								<input type="text" id="fees" name="fees" value="{{old('fees')}}" class="form-control" placeholder="Fees">
								@error('fees')
								<span class="text-danger">
									{{$message}}		
								</span>
								@enderror
							</div>
						</div>
					</div>
				</div>
				<div class="row add_cat_submit mt-3">
					<div class="col-lg-2"></div>
					<div class="col-lg-10">
						<a href="{{ route('admin.colleges.mou') }}"><button type="button" class="btn btn-danger">Cancel</button></a>
						<button type="submit" class="btn btn-success">Submit</button>
					</div>
				</div>
				<input type="hidden" id="hid_course_id" name="hid_course_id" value="{{old('hid_course_id')}}"/>
				<input type="hidden" id="college_id" name="college_id" value="{{$college_id}}"/>
			</div>
			</form>
		</div>
        <div class="card">
			<div class="card-body">
			<div class="row">
				<div class="col-lg-6">
					<h1 class="h3 mb-3"><strong></strong>College Courses</h1>
				</div>
				<div class="col-lg-6 text-end">
					<div class="btn-group">
						<button type="button" class="btn btn-danger dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">Action</button>
						<ul class="dropdown-menu">
							<li><a class="dropdown-item" href="javascript:void(0)" id="delete_records" data-url="{{url('admin/college/multi_course_delete')}}">Delete</a></li>
						</ul>
					</div>
				</div>
			</div>
				<div class="table-responsive categoryTable">
					<table id="example" class="table table-bordered table-striped table-hover" style="width:100%">
						<thead>
							<tr class="cmsHead">
								<th>
									<label class="form-check form-check-inline">
										<input class="form-check-input" type="checkbox" id="checkAll">
									</label>
								</th>
								<th>Course</th>
								<th>Fees</th>
								<th class="text-center">Options</th>
							</tr>
						</thead>
						<tbody>
							@foreach($data as $list)
							<tr class="cmsBody">
								<td>
									<label class="form-check form-check-inline">
										<input class="form-check-input" type="checkbox" name="chk_id" data-emp-id="{{$list->id}}">
									</label>
								</td>
								<td class="">{{$list->course_details->name}}</td>
								<td class="">{{currency()}} {{$list->fees}}</td>
								<td class="optionsDetails text-center">
									
									<a class="deleteMode delete-data" href="javascript:void(0)" data-id="{{$list->id}}" data-url="{{url('admin/college-course/delete')}}"><i class="align-middle me-2" data-feather="trash-2" data-toggle="tooltip" title="Delete"></i><span class="align-middle"></span></a>
									
									<a class="editMode txtLink" href="javascript:void(0)" data-id="{{$list->id}}" data-url="{{url('admin/college/college-course-details')}}"><i class="align-middle me-2" data-feather="edit-2" data-toggle="tooltip" title="Edit"></i></a>
									
								</td>
							</tr>
							@endforeach
						</tbody>
					</table>
				</div>
			</div>
		</div>
    </div>
</main>
@endsection
@section('scripts')
<script type="text/javascript">
$(document).ready(function (e) {
	$('.editMode').click(function(){
		$('#form_type').text('Edit');
		var url = $(this).data('url');
		var selected_id = $(this).data('id');
		var college_id = $('#college_id').val();
		$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			 }
		});
		$.ajax({
			url: url,
			method: "POST",
			data: {id:selected_id,college_id:college_id},
			dataType: 'json',
			success: function(response) {
				$('#course').html(response.course);
				$('#fees').val(response.fees);
				$('#hid_course_id').val(response.hid_course_id);
			}
		});
	});
	$('.upload').change(function(){
		var id = $(this).data('id');
		let reader = new FileReader();
		reader.onload = (e) => {
			$("#imgSrc"+id).attr('src', e.target.result);
		}
		reader.readAsDataURL(this.files[0]);
	});
});
</script>
@endsection