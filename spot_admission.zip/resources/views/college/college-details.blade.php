@extends('layouts.app')
@section('content')
 <!-- crumbs area start -->
    <div class="crumbs-area">
        <div class="container">
            <div class="crumb-content">
                <h4 class="crumb-title"><span>College</span> Details</h4>
            </div>
        </div>
    </div>
    <!-- crumbs area end -->
    <!-- course area start -->
    <div class="course-area pt--20 pb--50">
        <div class="container">
			<div class="row ptb--30">
                <div class="col-lg-2 col-md-2">
                    <img src="{{ isset($college_details->logo_image) && $college_details->logo_image!='' ? asset('images/colleges').'/'.$college_details->id.'/logo/'.$college_details->logo_image : asset('/images/noimage.png') }}" alt="image">
				</div>
				<div class="col-lg-8 col-md-8">
                    <h3 class="mb-4"><a href="#">{{$college_details->name}}</a></h3>
					<div class="course-dt-info">
						<ul class="course-meta-details list-inline border-0 w-100">
							<li> 
							 <p class="text-left">{{$college_details->address}}</p>
							</li>     
						</ul> 
					</div>
				</div>
				<div class="col-lg-2 col-md-2">
				@if(Auth::user())
					<a href="{{url('application/')}}/{{$college_details->id}}"><button type="button" class="apply_now_btn">Apply Now</button></a>
				@else
					<a href="{{ route('login') }}"><button type="button" class="apply_now_btn">Apply Now</button></a>
				@endif
				</div>
			</div>
            <div class="row">
                <!-- course details start -->
                <div class="col-lg-8 col-md-8">
                    <div class="course-details">
                        <div class="cs-thumb mb-5">
                         
							<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
								<ol class="carousel-indicators">
								@if(count($college_details->get_images) > 0)
									@php
										$i = 0;
									@endphp
									@foreach($college_details->get_images as $image_val)
									<li data-target="#carouselExampleIndicators" data-slide-to="{{$i}}" class="{{ $i==0 ? 'active':'' }}"></li>
									@php
										$i++;
									@endphp
									@endforeach
								@else
									<li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
								@endif
								</ol>
								<div class="carousel-inner">
								@if(count($college_details->get_images) > 0)
									@php
										$i = 0;
									@endphp
									@foreach($college_details->get_images as $image_val)
									<div class="carousel-item {{ $i==0 ? 'active':'' }}">
										<img class="d-block w-100" src="{{ isset($image_val->image) && $image_val->image!='' ? asset('images/colleges').'/'.$image_val->college_id.'/images/'.$image_val->image : asset('/images/noimage.png') }}" alt="{{ $image_val->image }}">
									</div>
									@php
										$i++;
									@endphp
									@endforeach
								@else
									<div class="carousel-item active">
										<img class="d-block w-100" src="{{ asset('/images/noimage.png') }}" alt="College images">
									</div>
								@endif	
								</div>
							  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
								<span class="carousel-control-prev-icon" aria-hidden="true"></span>
								<span class="sr-only">Previous</span>
							  </a>
							  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
								<span class="carousel-control-next-icon" aria-hidden="true"></span>
								<span class="sr-only">Next</span>
							  </a>
							</div>

                        </div>
						
						
						<ul class="nav nav-tabs" id="myTab" role="tablist">
							<li class="nav-item" role="presentation">
								<button class="nav-link active" id="info-tab" data-toggle="tab" data-target="#info" type="button" role="tab" aria-controls="info" aria-selected="true">Info</button>
							</li>
							<li class="nav-item" role="presentation">
								<button class="nav-link" id="courses-tab" data-toggle="tab" data-target="#courses" type="button" role="tab" aria-controls="courses" aria-selected="false">Courses & Fees</button>
							</li>
							<li class="nav-item" role="presentation">
								<button class="nav-link" id="placement-tab" data-toggle="tab" data-target="#placement" type="button" role="tab" aria-controls="placement" aria-selected="false">Placement</button>
							</li>
							<li class="nav-item" role="presentation">
								<button class="nav-link" id="faculty-tab" data-toggle="tab" data-target="#faculty" type="button" role="tab" aria-controls="faculty" aria-selected="false">Faculty</button>
							</li>
						</ul>
						<div class="tab-content" id="myTabContent">
						<!--Start Info-->
							<div class="tab-pane fade show active" id="info" role="tabpanel" aria-labelledby="info-tab">
							<p class="ptb--10">Description - {{$college_details->description}}</p>
							</div>
						<!--End Info-->
						<!--Start Courses & Fees-->
							<div class="tab-pane fade ptb--10" id="courses" role="tabpanel" aria-labelledby="courses-tab">
								<table class="table">
									<thead class="thead-primary">
										<tr>
											<th scope="col">Course</th>
											<th scope="col">Fees</th>
											<th scope="col">Eligibility</th>
											<th scope="col">Application Date</th>
										</tr>
									</thead>
									<tbody>
										@foreach($college_details->get_courses as $course_val)
										<tr>
											<th scope="row">{{ $course_val->course_details->name }}</th>
											<td>{{ currency()}} {{ $course_val->fees}} </td>
											<td>Graduation + CAT</td>
											<td>19 June - 01 Feb 2024</td>
										</tr>
										@endforeach
									</tbody>
								</table>
							</div>
						<!--End Courses & Fees-->
						<!--Start Placement-->	
							<div class="tab-pane fade" id="placement" role="tabpanel" aria-labelledby="placement-tab"><p class="ptb--10">Placement - {{$college_details->placement}}</p></div>
						<!--End Placement-->	
						<!--Start Faculty-->	
							<div class="tab-pane fade" id="faculty" role="tabpanel" aria-labelledby="faculty-tab">
								<!-- teacher area start -->
								<div class="all-teachers  pt--10">
									<div class="container">
										<div class="row">
										@if(count($college_details->get_images) > 0)
										@foreach($college_details->get_faculties as $faculty_val)
											<div class="col-lg-4 col-md-6">
											  <div class="card mb-5"> 
												<img src="{{ isset($faculty_val->faculty_image) && $faculty_val->faculty_image!='' ? asset('images/colleges').'/'.$faculty_val->college_id.'/faculty/'.$faculty_val->faculty_image : asset('/images/noimage.png') }}" alt="image"> 
												<div class="card-body teacher-content p-25">  
													<h4 class="card-title mb-1"><a href="">{{ $faculty_val->faculty_name }}</a></h4>
													{{--<span class="primary-color d-block mb-4">Financier</span>
												  
													<ul class="list-inline">
														<li><a href="#"><i class="fa fa-facebook"></i></a></li>
														<li><a href="#"><i class="fa fa-twitter"></i></a></li>
														<li><a href="#"><i class="fa fa-dribbble"></i></a></li>
														<li><a href="#"><i class="fa fa-deviantart"></i></a></li>
														<li><a href="#"><i class="fa fa-github"></i></a></li>
													</ul>--}}
												</div>
											  </div><!-- card --> 
											</div>
										@endforeach
										@else
											<div class="col-lg-12">
												No Faculty available
											</div>
										@endif
										</div>
									</div>
								</div>
								<!-- teacher area end -->
							</div>
						<!--End Faculty-->	
						</div>
						
                        
                    </div>
                </div>
                <!-- course details end -->
                <!-- sidebar start -->
                <div class="col-lg-4 col-md-4">
                    <div class="sidebar">
                        <!-- widget course start -->
                        <div class="widget widget-course">
                            <h4 class="widget-title">Similar Colleges</h4>
                            <div class="course-list">
                                <div class="w-cs-single">
                                    <img src="{{ url('front-assets/images/course/cs-small-thumb1.jpg') }}" alt="image">
                                    <div class="fix">
                                        <p><a href="#">Ui / Ux Design</a></p>
                                        <span><i class="fa fa-clock-o"></i> AUGUST 6, 2017</span>
                                    </div>
                                </div>
                                <div class="w-cs-single">
                                    <img src="{{ url('front-assets/images/course/cs-small-thumb2.jpg') }}" alt="image">
                                    <div class="fix">
                                        <p><a href="#">Learn Java</a></p>
                                        <span><i class="fa fa-clock-o"></i> AUGUST 6, 2017</span>
                                    </div>
                                </div>
                                <div class="w-cs-single">
                                    <img src="{{ url('front-assets/images/course/cs-small-thumb3.jpg') }}" alt="image">
                                    <div class="fix">
                                        <p><a href="#">C++</a></p>
                                        <span><i class="fa fa-clock-o"></i> AUGUST 6, 2017</span>
                                    </div>
                                </div>
                                <div class="w-cs-single">
                                    <img src="{{ url('front-assets/images/course/cs-small-thumb4.jpg') }}" alt="image">
                                    <div class="fix">
                                        <p><a href="#">Seo</a></p>
                                        <span><i class="fa fa-clock-o"></i> AUGUST 6, 2017</span>
                                    </div>
                                </div>
                                <div class="w-cs-single">
                                    <img src="{{ url('front-assets/images/course/cs-small-thumb5.jpg') }}" alt="image">
                                    <div class="fix">
                                        <p><a href="#">Python</a></p>
                                        <span><i class="fa fa-clock-o"></i> AUGUST 6, 2017</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- widget course end -->
                    </div>
                </div>
                <!-- sidebar end -->
            </div>
        </div>
    </div>
    <!-- course area end -->
@endsection
@section('scripts')

@endsection

