@extends('layouts.app')
@section('content')
	<!-- =-=-=-=-=-=-= Breadcrumb =-=-=-=-=-=-= -->
  <div class="page-header-area-2 gray">
	 <div class="container">
		<div class="row">
		   <div class="col-lg-3 col-md-6 col-sm-12 col-xs-12"></div>
		   <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
				<div class="mb-4 text-sm text-gray-600">
					{{ __('verify_email_signing_up') }}
				</div>

				@if (session('status') == 'verification-link-sent')
					<div class="mb-4 font-medium text-sm text-green-600  text-success">
						{{ __('verify_email_link_sent') }}
					</div>
				@endif
				
				<form method="POST" action="{{ route('verification.send') }}">
					@csrf

					<div>
						<button class="btn btn-theme btn-lg btn-block">{{ __('verify_email_resend') }}</button>
					</div>
				</form>
		   </div>
		   <div class="col-lg-3 col-md-6 col-sm-12 col-xs-12"></div>
		</div>
	 </div>
  </div>
  <!-- =-=-=-=-=-=-= Breadcrumb End =-=-=-=-=-=-= -->
@endsection
