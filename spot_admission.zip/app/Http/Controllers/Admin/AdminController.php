<?php
namespace App\Http\Controllers\Admin;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Hash;
use Auth;
use App\Models\Admin;
use App\Models\User;
use App\Mail\Websitemail;

class AdminController extends Controller
{
    public function dashboard()
    {
        return view('admin.dashboard');
    }
    public function login()
    {
        return view('admin.auth.login');
    }
    public function login_submit(Request $request)
    {
        //dd($request->all());
        $request->validate([
            'email' => 'required|email',
            'password' => 'required',
        ]);

        $check = $request->all();
        $data = [
            'email' => $check['email'],
            'password' => $check['password'],
        ];
		
        if(Auth::guard('admin')->attempt($data)) {
            return redirect()->route('admin.dashboard')->with('success','Login Successfull');
        } else {
            return redirect()->route('admin_login')->with('error','Invalid Credentials');
        }
    }
    public function logout()
    {
        Auth::guard('admin')->logout();
        return redirect()->route('admin_login')->with('success','Logout Successfully');
    }

    public function forget_password()
    {
        return view('admin.auth.forget-password');
    }

    public function forget_password_submit(Request $request)
    {   
        $request->validate([
            'email' => 'required|email',
        ]);

        $admin_data = Admin::where('email',$request->email)->first();
        if(!$admin_data) {
            return redirect()->back()->with('error','Email not found');
        }

        $token = hash('sha256',time());
        $admin_data->token = $token;
        $admin_data->update();

        $reset_link = url('admin/reset-password/'.$token.'/'.$request->email);
        $subject = "Reset Password";
        $message = "Please click on below link to reset your password<br><br>";
        $message .= "<a href='".$reset_link."'>Click Here</a>";

        \Mail::to($request->email)->send(new Websitemail($subject,$message));

        return redirect()->back()->with('success','Reset password link sent on your email');
    }

    public function reset_password($token,$email)
    {
        $admin_data = Admin::where('email',$email)->where('token',$token)->first();
        if(!$admin_data) {
            return redirect()->route('admin_login')->with('error','Invalid token or email');
        }
        return view('admin.auth.reset-password', compact('token','email'));
    }

    public function reset_password_submit(Request $request)
    {
        $request->validate([
            'password' => 'required',
            'password_confirmation' => 'required|same:password',
        ]);

        $admin_data = Admin::where('email',$request->email)->where('token',$request->token)->first();
        $admin_data->password = Hash::make($request->password);
        $admin_data->token = "";
        $admin_data->update();

        return redirect()->route('admin_login')->with('success','Password reset successfully');
    }


    //agent controller;


    public function index()
    {
		$data = Admin::query()->where('status', '!=', 2)->where('user_type', 1)->get();
		$result['data']=$data;
        return view('admin.agent.agent',$result);
    }
   public function manage_agent(Request $request,$id='')
    {
		$result = [];
		if($id>0){				
			$arr = Admin::query()->where('id', $id)->first();
			if($arr){
				$result['name']=$arr->name;
                $result['email']=$arr->email;
				$result['id']=$arr->id;
			}else{
				$result['name']='';
                $result['email']='';
				$result['id']= $id;
			}
        }else{
			$result['name']='';
            $result['email']='';
			$result['id']=0;
        }
        return view('admin.agent.manage_agent',$result);
    }
    public function manage_agent_process(Request $request)
    {
        if($request->post('id')>0){
            //echo 1;exit;
            $id =$request->post('id');

            $request->validate([ 
                'name'=>'required',
                'email' => 'required|email|unique:admins,email,'.$id,
              ]);
        }else{
           // echo 2;exit;
            $request->validate([
                'name'=>'required',
                'email' => 'required|email|unique:admins',
                'password'=>'required|min:8',
            ]);
        }
        if($request->post('id')>0){
			$model=Admin::find($request->post('id'));
			$model->name=$request->post('name');
            $model->email=$request->post('email');
            if($request->post('password') && $request->post('password')!=''){
            $model->password=$request->post('password');
            }
            $model->user_type=1;
			$model->updated_at=date('Y-m-d H:i:s');
			$model->save();
            $msg="Agent has been updated successfully.";

        }else{
            $model=new Admin();
			//$model->status=1;
			$model->name=$request->post('name');
            $model->email=$request->post('email');
            $model->password=$request->post('password');
            $model->user_type=1;
			$model->updated_at=null;
			$model->save();
            $msg="New Agent has been added successfully.";
        }
        $request->session()->flash('message',$msg);
        return redirect('admin/agent');
        
    }
	public function delete(Request $request){
		$deleted = Admin::where('id',$request->id)
			->update(['status'=>2]);
        if($deleted){
			$request->session()->flash('message','Agent has been deleted successfully.');
			return response()->json(['success'=>'Agenthas been deleted successfully.']);
		}else{
			return response()->json(['success'=>'Agent not deleted.']);
		}
    }
	public function multi_delete(Request $request){
		$ids = explode(',',$request->id);
		$deleted = Admin::whereIn('id',$ids)
			->update(['status'=>2]);
        if($deleted){
			$request->session()->flash('message','Agent has been deleted successfully.');
			return response()->json(['success'=>'Agent has been deleted successfully.']);
		}else{
			return response()->json(['success'=>'Agent not deleted.']);
		}
    }
	public function status(Request $request){
		$updated = Admin::where('id',$request->id)
			->update(['status'=>$request->val]);
        
        if($updated){
			$request->session()->flash('message','Agent status has been updated successfully.');
			return response()->json(['success'=>'Agent status has been updated successfully.']);
		}else{
			return response()->json(['success'=>'Agent not updated.']);
		}
    }
	public function multi_change_status(Request $request){
		$cat_ids = explode(',',$request->id);
		$updated = Admin::whereIn('id',$cat_ids)
				->update(['status'=>$request->status]);
        if($updated){
			$request->session()->flash('message','Agent status has been updated successfully.');
			return response()->json(['success'=>'Agent status has been updated successfully.']);
		}else{
			return response()->json(['success'=>'Agent not updated.']);
		}
    }
    //Institution Controller
    public function institutions()
    {
		$data = Admin::query()->where('status', '!=', 2)->where('user_type', 2)->get();
		$result['data']=$data;
        return view('admin.Institution.institution',$result);
    }
   public function manage_institution(Request $request,$id='')
    {
		$result = [];
		if($id>0){				
			$arr = Admin::query()->where('id', $id)->first();
			if($arr){
				$result['name']=$arr->name;
                $result['email']=$arr->email;
				$result['id']=$arr->id;
			}else{
				$result['name']='';
                $result['email']='';
				$result['id']= $id;
			}
        }else{
			$result['name']='';
            $result['email']='';
			$result['id']=0;
        }
        return view('admin.institution.manage_institution',$result);
    }
    public function manage_institution_process(Request $request)
    {
        if($request->post('id')>0){
            //echo 1;exit;
            $id =$request->post('id');

            $request->validate([ 
                'name'=>'required',
                'email' => 'required|email|unique:admins,email,'.$id,
              ]);
        }else{
           // echo 2;exit;
            $request->validate([
                'name'=>'required',
                'email' => 'required|email|unique:admins',
                //'password'=>'required|min:8',
            ]);
        }
        if($request->post('id')>0){
			$model=Admin::find($request->post('id'));
			$model->name=$request->post('name');
            $model->email=$request->post('email');
            if($request->post('password') && $request->post('password')!=''){
            $model->password=$request->post('password');
            }
            $model->user_type=2;
			$model->updated_at=date('Y-m-d H:i:s');
			$model->save();
            $msg="Institution has been updated successfully.";

        }else{
            $model=new Admin();
			//$model->status=2;
			$model->name=$request->post('name');
            $model->email=$request->post('email');
            $model->password=$request->post('password');
            $model->user_type=2;
			$model->updated_at=null;
			$model->save();
            $msg="New Institution has been added successfully.";
        }
        $request->session()->flash('message',$msg);
        return redirect('admin/institutions');
        
    }
	public function remove(Request $request){
		$deleted = Admin::where('id',$request->id)
			->update(['status'=>2]);
        if($deleted){
			$request->session()->flash('message','Institution has been deleted successfully.');
			return response()->json(['success'=>'Institution been deleted successfully.']);
		}else{
			return response()->json(['success'=>'Institution not deleted.']);
		}
    }
	public function multi_remove(Request $request){
		$ids = explode(',',$request->id);
		$deleted = Admin::whereIn('id',$ids)
			->update(['status'=>2]);
        if($deleted){
			$request->session()->flash('message','Institution has been deleted successfully.');
			return response()->json(['success'=>'Institution has been deleted successfully.']);
		}else{
			return response()->json(['success'=>'Institution not deleted.']);
		}
    }
	public function status1(Request $request){
		$updated = Admin::where('id',$request->id)
			->update(['status'=>$request->val]);
        
        if($updated){
			$request->session()->flash('message','Institution status has been updated successfully.');
			return response()->json(['success'=>'Institution status has been updated successfully.']);
		}else{
			return response()->json(['success'=>'Institution not updated.']);
		}
    }
	public function multi_change_status1(Request $request){
		$cat_ids = explode(',',$request->id);
		$updated = Admin::whereIn('id',$cat_ids)
				->update(['status'=>$request->status]);
        if($updated){
			$request->session()->flash('message','Institution status has been updated successfully.');
			return response()->json(['success'=>'Institution status has been updated successfully.']);
		}else{
			return response()->json(['success'=>'Institution not updated.']);
		}
    }
}
