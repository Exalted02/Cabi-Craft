<!doctype html>
<html class="no-js" lang="{{ str_replace('_', '-', app()->getLocale()) }}">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="x-ua-compatible" content="ie=edge">
		<title>{{ config('app.name', 'Laravel') }}</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<!-- Place favicon.ico in the root directory -->
		<link rel="shortcut icon" type="image/png" href="{{ url('images/favicon.png') }}">
		<!-- all css here -->
		<link rel="stylesheet" href="{{ url('front-assets/css/bootstrap.min.css') }}">
		<link rel="stylesheet" href="{{ url('front-assets/css/font-awesome.min.css') }}">
		<link rel="stylesheet" href="{{ url('front-assets/css/owl.carousel.min.css') }}">
		<link rel="stylesheet" href="{{ url('front-assets/css/magnific-popup.css') }}">
		<link rel="stylesheet" href="{{ url('front-assets/css/slicknav.min.css') }}">
		<link rel="stylesheet" href="{{ url('front-assets/css/typography.css') }}">
		<link rel="stylesheet" href="{{ url('front-assets/css/default-css.css') }}">
		<link rel="stylesheet" href="{{ url('front-assets/css/styles.css') }}">
		<link rel="stylesheet" href="{{ url('front-assets/css/responsive.css') }}">
		<!--color css-->
		<link rel="stylesheet" id="triggerColor" href="{{ url('front-assets/css/triggerplate/color-0.css') }}">
		<!-- modernizr css -->
		<script src="{{ url('front-assets/js/vendor/modernizr-2.8.3.min.js') }}"></script>
	</head>

	<body>
		<div id="preloader">
			<div class="loader"></div>
		</div>
		<header id="header">
		@if(!request()->routeIs('home'))
			@include('_includes/top-header')
		@endif
		@if(!request()->routeIs('home'))
			@include('_includes/inner-header')
		@else
			@include('_includes/home-header')
		@endif
		</header>
		<div class="offset-search">
			<form action="#">
				<input type="text" name="search" placeholder="Sarch here...">
				<button type="submit"><i class="fa fa-search"></i></button>
			</form>
		</div>
		<!-- offset search area end -->
		<!-- body overlay area start -->
		<div class="body_overlay"></div>
		<!-- body overlay area end -->
		
			@yield('content')

        @include('_includes/footer')
		<!-- =-=-=-=-=-=-= JQUERY =-=-=-=-=-=-= -->
		<!-- jquery latest version -->
		<script src="{{ url('front-assets/js/vendor/jquery-2.2.4.min.js') }}"></script>
		<!-- bootstrap 4 js -->
		<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
		<script src="{{ url('front-assets/js/bootstrap.min.js') }}"></script>
		<!-- others plugins -->
		<script src="{{ url('front-assets/js/owl.carousel.min.js') }}"></script>
		<script src="{{ url('front-assets/js/jquery.magnific-popup.min.js') }}"></script>
		<script src="{{ url('front-assets/js/jquery.slicknav.min.js') }}"></script>
		<script src="{{ url('front-assets/js/plugins.js') }}"></script>
		<script src="{{ url('front-assets/js/scripts.js') }}"></script>
		
		<link rel="stylesheet" href="{{ url('common-assets/css/toastr.min.css') }}"/>
		<script src="{{ url('common-assets/js/toastr.min.js') }}"></script>
		<script>
			@if(Session::has('message'))
				var msg = "{{ session('message') }}";
				var type = 'success';
				toastr_msg(msg, type);
			@endif

			@if(Session::has('error'))
				var msg = "{{ session('error') }}";
				var type = 'error';
				toastr_msg(msg, type);
			@endif

			@if(Session::has('info'))
				var msg = "{{ session('info') }}";
				var type = 'info';
				toastr_msg(msg, type);
			@endif

			@if(Session::has('warning'))
				var msg = "{{ session('warning') }}";
				var type = 'warning';
				toastr_msg(msg, type);
			@endif
			function toastr_msg(msg, type){
				toastr.options =
				{
					"closeButton" : true,
					"progressBar" : true
				}
				toastr[type](msg);
			}
		</script>
		@yield('scripts')
	</body>
</html>
