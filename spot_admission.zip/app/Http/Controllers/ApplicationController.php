<?php

namespace App\Http\Controllers;

// use App\Http\Requests\ProfileUpdateRequest;
// use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use App\Models\User;
use Illuminate\Validation\Rules;
use Illuminate\Support\Facades\Hash;
// use Illuminate\View\View;
use Lang;

class ApplicationController extends Controller
{
    public function application($id)
    {
		$data['id'] = $id;
		return view('college.application', $data);
    }
    public function profile_submit(Request $request)
    {
		// dd($request->all());
		$request->validate([
			'name'=>'required',
			'contact_number'=>'required',
			//'country'=>'required',
			//'state'=>'required',
			//'city'=>'required',
			//'zip_code'=>'required',
			//'address'=>'required',
			//'profile_picture.*' => 'required|image|mimes:jpeg,png,jpg,gif|max:2048',
			// 'terms_service' => 'required',
			'password' => ['nullable', 'min:8', 'confirmed'],
		],[
			// 'terms_service' => 'Please select terms and service.'
		]);
		$get_user_details = get_user_details();
		/*$imageName = $get_user_details->profile_picture;
		if($request->hasFile('profile_picture')){
			$dest_path = public_path('images/').Auth::user()->username.'/avatar/';
			$dest_thumb_path = public_path('images/').Auth::user()->username.'/avatar/thumbs/';
			foreach ($request->profile_picture as $k=>$file) {
				$imageName = uploadResizeImage('', $dest_path, $dest_thumb_path, 1280, 250, $file);
			}
		}*/
		// dd($imageName);
		if($request->password && $request->password != ''){
			$pass = Hash::make($request->password);
		}else{
			$pass = $get_user_details->password;
		}
		$data = User::updateOrCreate([
            'id' => Auth::user()->id,
        ], [
            'name' => $request->post('name'),
            'contact_number' =>  $request->post('contact_number'),
            /*'company_name' =>  $request->post('company_name'),
            'country' =>  $request->post('country'),
            'state' =>  $request->post('state'),
            'city' =>  $request->post('city'),
            'zip_code' =>  $request->post('zip_code'),
            'address' => $request->post('address'),
            'profile_picture' => $imageName,*/
            'password' => $pass,
            'updated_at' => date('Y-m-d H:i:s'),
        ]);
		// dd($data);
		$msg='Profile updated successfully';
		$request->session()->flash('message',$msg);
        return redirect('/profile');
    }
	/*public function delete_profile_image(Request $request)
	{
		$path = 'images/'.auth()->user()->username.'/avatar/'.$request->profile_img;
		
		unlink($path);
		//if(File::exists(public_path($path))) {
		//	File::delete(public_path($path));
		//}
		User::where('id',auth()->user()->id)->update(['profile_picture'=>'']);
	}*/
}
