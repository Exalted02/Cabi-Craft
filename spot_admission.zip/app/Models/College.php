<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class College extends Model
{
    use HasFactory;
	
	protected $fillable = [
        'name',
        'address',
        'logo_image',
        'video_link',
        'description',
        'placement',
        'college_type',
        'status',
    ];
	
	public function get_images()
    {
        return $this->hasMany(College_images::class, 'college_id', 'id');
    }
	public function get_courses()
    {
        return $this->hasMany(College_course::class, 'college_id', 'id');
    }
	public function get_faculties()
    {
        return $this->hasMany(College_faculties::class, 'college_id', 'id');
    }
}
