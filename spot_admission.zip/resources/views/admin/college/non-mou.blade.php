@extends('admin.layouts.app')

@section('content')
<main class="content">
	<div class="container-fluid p-0">
		<div class="row">
			<div class="col-lg-6">
				<h1 class="h3 mb-3"><strong></strong>Non Mou Colleges</h1>
			</div>
			<div class="col-lg-6 text-end">
				<a href="{{ route('admin.college.add-non-mou-college') }}"><button type="button" class="btn btn-danger">Add New</button></a>
				<div class="btn-group">
					<button type="button" class="btn btn-danger dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">Action</button>
					<ul class="dropdown-menu">
						<li><a class="dropdown-item change_status" href="javascript:void(0)" data-id="1" data-url="{{url('admin/college/multi_change_status')}}">Active</a></li>
						<li><a class="dropdown-item change_status" href="javascript:void(0)" data-id="0" data-url="{{url('admin/college/multi_change_status')}}">Inactive</a></li>
						<li><a class="dropdown-item" href="javascript:void(0)" id="delete_records" data-url="{{url('admin/college/multi_delete')}}">Delete</a></li>
					</ul>
				</div>
			</div>
		</div>
        <div id="message"></div>
		@if(session('message') )
		<div class="alert alert-success alert-dismissible fade show">
			<strong>{{session('message')}}</strong> 
			<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="btn-close">
			</button>
		</div>
		@endif
        <div class="card">
			<div class="card-body">
				<div class="table-responsive categoryTable">
					<table id="example" class="table table-bordered table-striped table-hover" style="width:100%">
						<thead>
							<tr class="cmsHead">
								<th>
									<label class="form-check form-check-inline">
										<input class="form-check-input" type="checkbox" id="checkAll">
									</label>
								</th>
								<th>Name</th>
								<th class="text-center">Status</th>
								<th class="text-center">Options</th>
							</tr>
						</thead>
						<tbody>
							@foreach($data as $list)
							<tr class="cmsBody">
								<td>
									<label class="form-check form-check-inline">
										<input class="form-check-input" type="checkbox" name="chk_id" data-emp-id="{{$list->id}}">
									</label>
								</td>
								<td>{{$list->name}}</td>
								<td class="text-center">
									<label class="switch">
										<input type="checkbox" class="changeStatus" data-id="{{$list->id}}" data-url="{{url('admin/college/status')}}" {{$list->status==1 ? 'checked' : ''}}>
										<span class="slider round"></span>
									</label>
								</td>
								<td class="optionsDetails text-center">
									
									<a class="deleteMode delete-data" href="javascript:void(0)" data-id="{{$list->id}}" data-url="{{url('admin/college/delete')}}"><i class="align-middle me-2" data-feather="trash-2" data-toggle="tooltip" title="Delete"></i><span class="align-middle"></span></a>
									
									<a class="editMode txtLink" href="{{url('admin/college/update-non-mou-college/')}}/{{$list->id}}"><i class="align-middle me-2" data-feather="edit" data-toggle="tooltip" title="Edit"></i></a>
									
									<a class="text-primary" href="{{url('admin/college/college-images/')}}/{{$list->id}}"><i class="align-middle me-2" data-feather="image" data-toggle="tooltip" title="Image"></i></a>
									
									<a class="text-warning" href="{{url('admin/college/college-course/')}}/{{$list->id}}"><i class="align-middle me-2" data-feather="columns" data-toggle="tooltip" title="Course"></i></a>
									
									{{--<a class="text-info" href="{{url('admin/college/college-faculty/')}}/{{$list->id}}"><i class="align-middle me-2" data-feather="user" data-toggle="tooltip" title="Faculty"></i></a>--}}
									
								</td>
							</tr>
							@endforeach
						</tbody>
					</table>
				</div>
			</div>
		</div>
    </div>
</main>
@endsection