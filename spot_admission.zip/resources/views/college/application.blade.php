@extends('layouts.app')
@section('content')

<div class="crumbs-area">
	<div class="container">
		<div class="crumb-content">
			<h4 class="crumb-title"><span>Application Form </span></h4>
		</div>
	</div>
</div>
<!-- crumbs area end -->
<div class="contact-form-area pb--120">
	<div class="container">
		<div class="row">
		<div class="col-md-12">
		<div class="row">
			<div class="col-md-12">
				<div class="cnt-title">
					<h4>Application Form<span></span></h4>
					{{--<p>Quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut </p>--}}
				</div>
			</div>
		</div>
		<div class="contact-form">
			<form action="{{ route('profile_submit') }}" method="post" enctype="multipart/form-data">
			@csrf
				<div class="row">
					<div class="col-md-4 offset-md-1">
						<input type="text" id="name" name="name"  placeholder="Student's Name" class="" value="">
						@error('name')
						<span class="text-danger">
							{{ $message }}
						</span>
						@enderror
					</div>
					<div class="col-md-4 offset-md-1">
						<input type="text" id="name" name="name"  placeholder="Father's Name" class="" value="">
						@error('name')
						<span class="text-danger">
							{{ $message }}
						</span>
						@enderror
					</div>
					<div class="col-md-4 offset-md-1">
						<input type="text" id="name" name="name"  placeholder="Mother's Name" class="" value="">
						@error('name')
						<span class="text-danger">
							{{ $message }}
						</span>
						@enderror
					</div>
					<div class="col-md-4 offset-md-1">
						<input type="text" id="name" name="name"  placeholder="Phone No" class="" value="">
						@error('name')
						<span class="text-danger">
							{{ $message }}
						</span>
						@enderror
					</div>
					<div class="col-md-4 offset-md-1">
						<input type="text" id="name" name="name"  placeholder="DoB" class="" value="">
						@error('name')
						<span class="text-danger">
							{{ $message }}
						</span>
						@enderror
					</div>
					<div class="col-md-9 offset-md-1">
						<input type="text" id="name" name="name"  placeholder="Address" class="" value="">
						@error('name')
						<span class="text-danger">
							{{ $message }}
						</span>
						@enderror
					</div>
					<div class="col-md-4 offset-md-1">
						<input type="text" id="name" name="name"  placeholder="12th/Graduation/Diploma Percentage" class="" value="">
						@error('name')
						<span class="text-danger">
							{{ $message }}
						</span>
						@enderror
					</div>
					<div class="col-md-4 offset-md-1">
						<input type="text" id="name" name="name"  placeholder="Entrance Exam Marks Rank" class="" value="">
						@error('name')
						<span class="text-danger">
							{{ $message }}
						</span>
						@enderror
					</div>
					<div class="col-md-4 offset-md-1">
						<input type="file" id="name" name="name">
						@error('name')
						<span class="text-danger">
							{{ $message }}
						</span>
						@enderror
					</div>
					<div class="col-md-4 offset-md-1">
						<input type="file" id="name" name="name">
						@error('name')
						<span class="text-danger">
							{{ $message }}
						</span>
						@enderror
					</div>
					<div class="col-md-8 offset-md-2 text-center">
						<button type="submit">SUBMIT</button>
					</div>
				</div>
			</form>
		</div>
	
		</div>
		</div>
	</div>
</div>
	
@endsection
@section('scripts')
<script>

</script>
@endsection
