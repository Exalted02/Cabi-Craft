<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\College;

class FrontendController extends Controller
{	
	public function index()
	{
		$result['colleges'] = College::query()->where('status', 1)->orderBy('created_at', 'desc')->limit(3)->get();
        return view('home', $result);
	}
	public function all_colleges()
	{
		$result['colleges'] = College::query()->where('status', 1)->orderBy('created_at', 'desc')->get();
        return view('college.colleges', $result);
	}
	public function college_details($id)
	{
		$result['college_details'] = College::query()->where('id', $id)->with(['get_images','get_courses.course_details','get_faculties'])->first();
		// dd($result['college_details']);
        return view('college.college-details', $result);
	}
}
